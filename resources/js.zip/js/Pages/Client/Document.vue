<template>
    <div style="background-color: #f9f9f9;">
      <div class="container px-4 lg: lg:max-w-screen-xl mx-auto pt-18 pt-[80px] lg:pt-[135px]">
        <div class="bg-white shadow lg:p-8 lg:pt-8 p-8 pt-0 lg:mt-8">
          <div class="border-b">
            <h1 class="text-4xl text-black font-bold py-6 ">Documents and Software</h1>
            <h1 class="text-2xl font-light">
              Easy access to additional documents and software for product both current and obsolete.
            </h1>
            <div class="border-b pb-8 mt-5 lg:mt-0 mb-5">
              <div class="grid lg:grid-cols-2 items-center">
                <div class="grid items-center">
                  <h6 class="text-primary text-xl">
                    C6200.0100 FlexGen Controller
                  </h6>
                  <ul class="lg:pt-5 list-disc lg:w-auto w-40">
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        C6200/S6000/S6100/S6500/S6600/S6610 Flash Tool 3beta zip
                      </Link>
                    </li>
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        RS485
                        Bus Wiring</Link>
                    </li>
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        Configuration Software</Link>
                    </li>
                  </ul>
                </div>

                <div class="flex justify-end items-center">
                  <img width="300" height="300" class="" src="/images/C6200-600x600-300x300.jpg" />
                </div>
              </div>
            </div>
            <div class="border-b pb-8 mt-5 lg:mt-0 mb-5">
              <div class="grid lg:grid-cols-2 items-center">
                <div class="grid items-center">
                  <h6 class="text-primary text-xl">
                    C6200.0100 FlexGen Controller
                  </h6>
                  <ul class="lg:pt-5 list-disc lg:w-auto w-40">
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        C6200/S6000/S6100/S6500/S6600/S6610 Flash Tool 3beta zip
                      </Link>
                    </li>
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        RS485
                        Bus Wiring</Link>
                    </li>
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        Configuration Software</Link>
                    </li>
                  </ul>
                </div>

                <div class="flex justify-end items-center">
                  <img width="300" height="300" class="" src="/images/C6200-600x600-300x300.jpg" />
                </div>
              </div>
            </div>
            <div class="border-b pb-8 mt-5 lg:mt-0 mb-5">
              <div class="grid lg:grid-cols-2 items-center">
                <div class="grid items-center">
                  <h6 class="text-primary text-xl">
                    C6200.0100 FlexGen Controller
                  </h6>
                  <ul class="lg:pt-5 list-disc lg:w-auto w-40">
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        C6200/S6000/S6100/S6500/S6600/S6610 Flash Tool 3beta zip
                      </Link>
                    </li>
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        RS485
                        Bus Wiring</Link>
                    </li>
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        Configuration Software</Link>
                    </li>
                  </ul>
                </div>

                <div class="flex justify-end items-center">
                  <img width="300" height="300" class="" src="/images/C6200-600x600-300x300.jpg" />
                </div>
              </div>
            </div>
            <div class="border-b pb-8 mt-5 lg:mt-0 mb-5">
              <div class="grid lg:grid-cols-2 items-center">
                <div class="grid items-center">
                  <h6 class="text-primary text-xl">
                    C6200.0100 FlexGen Controller
                  </h6>
                  <ul class="lg:pt-5 list-disc lg:w-auto w-40">
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        C6200/S6000/S6100/S6500/S6600/S6610 Flash Tool 3beta zip
                      </Link>
                    </li>
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        RS485
                        Bus Wiring</Link>
                    </li>
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        Configuration Software</Link>
                    </li>
                  </ul>
                </div>

                <div class="flex justify-end items-center">
                  <img width="300" height="300" class="" src="/images/C6200-600x600-300x300.jpg" />
                </div>
              </div>
            </div>
            <div class="border-b pb-8 mt-5 lg:mt-0 mb-5">
              <div class="grid lg:grid-cols-2 items-center">
                <div class="grid items-center">
                  <h6 class="text-primary text-xl">
                    C6200.0100 FlexGen Controller
                  </h6>
                  <ul class="lg:pt-5 list-disc lg:w-auto w-40">
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        C6200/S6000/S6100/S6500/S6600/S6610 Flash Tool 3beta zip
                      </Link>
                    </li>
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        RS485
                        Bus Wiring</Link>
                    </li>
                    <li class="py-2">
                      <Link
                        class="underline text-subPrimary hover:no-underline hover:text-primary lg:text-lg text-sm font-semibold">
                        Configuration Software</Link>
                    </li>
                  </ul>
                </div>

                <div class="flex justify-end items-center">
                  <img width="300" height="300" class="" src="/images/C6200-600x600-300x300.jpg" />
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  </template>

  <script lang="ts" setup>

  </script>

  <style></style>
